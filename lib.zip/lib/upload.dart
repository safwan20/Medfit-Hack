import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_audio_recorder/flutter_audio_recorder.dart';
import 'package:medical/predict.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:async';
import 'dart:io' as io;
import 'package:file/file.dart';
import 'package:file/local.dart';



class FilePick extends StatefulWidget {
  @override
  _FilePickState createState() => _FilePickState();
}

class _FilePickState extends State<FilePick> {

  void fileupload() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if(result != null) {
      PlatformFile file = result.files.first;

      print(file.path);
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => Show(file.path)));
    }
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      home: Scaffold(
          backgroundColor: Colors.lightBlueAccent,
        appBar: AppBar(
          title: Center(
            child: Text('MediFit'),
          ),
        ),
        body: Container(
          child: Center(
            child: RaisedButton.icon(
                  onPressed: fileupload,
                icon: Icon(Icons.file_upload),
                label: Text("upload file")
            ),
          ),
        )

      ),
    );
  }
}
