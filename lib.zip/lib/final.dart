import 'package:flutter/material.dart';
import 'package:medical/spinnerthree.dart';
import 'package:medical/spinnertwo.dart';
import 'package:rflutter_alert/rflutter_alert.dart';



class Final extends StatefulWidget {
  Final(this.path, this.answer);
  String answer;
  String path;

  @override
  State<StatefulWidget> createState() {
    return _FinalState(path, answer);
  }
}

class _FinalState extends State<Final> {
  _FinalState(this.path, this.answer);
  String answer, path;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.lightBlueAccent,
        appBar: AppBar(
          title: Center(
            child: Text('MediFit'),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              Text(answer),
              SizedBox(height: 40,),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: (){
                        Alert(
                          context: context,
                          title: "In Production",
                          desc: "Soon into development (details about the heart beats and heart rate etc)",
                        ).show();
                      },
                      child: Card(
                        child: ListTile(
                          title: Text(
                            'Heart beat details'
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: (){
                        Alert(
                          context: context,
                          title: "In Production",
                          desc: "Soon into development (details about the disease)",
                        ).show();
                      },
                      child: Card(
                        child: ListTile(
                          title: Text(
                              answer
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),

              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(
                            context, MaterialPageRoute(builder: (context) => SpinnerThree(path)));
                      },
                      child: Card(
                        child: ListTile(
                          title: Text(
                              'Show Wheezle and Crackles'
                          ),
                        ),
                      )
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: (){
                            Navigator.push(
                            context, MaterialPageRoute(builder: (context) => SpinnerTwo(path)));
                      },
                      child: Card(
                        child: ListTile(
                          title: Text(
                              'Show Spectogram'
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              )





            ],
          ),
        ),
      ),
    );
  }
}



