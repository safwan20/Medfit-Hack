import 'package:flutter/material.dart';
import 'package:medical/record.dart';
import 'package:medical/upload.dart';


void main() {
  return runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.lightBlueAccent,
        appBar: AppBar(
          title: Center(
            child: Text('MediFit'),
          ),
        ),
        body: Choice(),
      ),
    );
  }
}




class Choice extends StatefulWidget {
  @override
  _ChoiceState createState() => _ChoiceState();
}


class _ChoiceState extends State<Choice> {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
  Expanded(
    child: GestureDetector(
      onTap: () {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => FilePick()));
      },
      child: Card(
        child: ListTile(
              title: Text(
                'Upload File',
              ),
      ),
    ),
  ),
  ),
        Expanded(
          child: GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => MediFit()));
            },
            child: Card(
              child: ListTile(
                title: Text(
                  'Record',
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
