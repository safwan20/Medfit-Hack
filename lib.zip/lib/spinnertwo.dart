import 'dart:convert';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:medical/spectogram.dart';


class SpinnerTwo extends StatefulWidget {
  SpinnerTwo(this.path);
  String path;

  @override
  State<StatefulWidget> createState() {
    return _SpinnerTwoState(path);
  }
}


class _SpinnerTwoState extends State<SpinnerTwo> {
  _SpinnerTwoState(this.path);
  String answer, path;
  Dio dio = new Dio();
  Image img;

  @override
  void initState() {
    show();
    super.initState();
  }

  void show () async{
    var uri = 'http://192.168.1.107:5000/show_image';
    String filename = path.split('/').last;

    FormData formData = new FormData.fromMap({
      "file" :
      await MultipartFile.fromFile(path,filename : filename,),
    });

    Response respose = await dio.post(uri, data:formData);
    img = Image.memory(base64Decode(respose.data));
    Navigator.pop(context);
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => Spectogram(img)));
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SpinKitWave(
          color: Colors.grey,
          size: 100.0,
        ),
      ),
      backgroundColor: Colors.white,
    );
  }
}

