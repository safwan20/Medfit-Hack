import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter/material.dart';
import 'package:medical/Diagdetails.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:charts_flutter/flutter.dart' as charts;
import 'dataseries.dart';


class SpinnerThree extends StatefulWidget {
  SpinnerThree(this.answer);
  String answer;

  @override
  State<StatefulWidget> createState() {
    return _SpinnerThree(answer);
  }
}

class _SpinnerThree extends State<SpinnerThree> {
  _SpinnerThree(this.answer);
  String answer;

  List<DataSeries> data = [];

  List x = [];
  List y = [];

  final List color = [
  Colors.red,
  Colors.green,
  ];

  @override
  void initState() {
    show();
    super.initState();
  }


  void show () async{
    var uri = 'http://192.168.1.107:5000/wc';
    var response = await http.get(uri);
    print(response.body);
    final decoded = json.decode(response.body);
    for (var i = 0; i <2; i++) {
      if (i == 0) {
        data.add(DataSeries(
           "cracks",
            decoded["cracks"],
            charts.ColorUtil.fromDartColor(color[i])));
      }
      else {
        data.add(DataSeries(
            "wheezles",
            decoded["wheezles"],
            charts.ColorUtil.fromDartColor(color[i])));
      }
    }

    Navigator.pop(context);
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => Donut(data)));
  }

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SpinKitWave(
          color: Colors.grey,
          size: 100.0,
        ),
      ),
      backgroundColor: Colors.white,
    );
  }
}

